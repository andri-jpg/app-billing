<?php

$conn = mysqli_connect("localhost", "root", "", "app-billing");

?>